# TuneBridge 2.0 Architecture

## High-level flow

1. User pastes a playlist URL (or uploads JSON/CSV).
2. System detects provider via `parse_playlist_url`.
3. Public playlist is fetched (or file is parsed).
4. For each track the destination provider searches candidates.
5. Matching engine scores and classifies: matched / ambiguous / missing.
6. User reviews and can override ambiguous matches.
7. On confirm, destination playlist is created and tracks are added.
8. Shareable URL is returned.

## Adapter contract

Every provider implements `MusicProvider` (see `adapters/base.py`).

Capabilities are declared explicitly so the UI and engine know what is possible.

## Matching

Priority: ISRC → title+artist → album → duration → version tags.

Thresholds (configurable):
- ≥ 0.82 → matched (unless second candidate is too close)
- ≥ 0.55 → ambiguous
- below → missing

## Security

- Tokens live only on the server.
- Secrets never appear in frontend code or logs.
- Experimental adapters require explicit enablement.
