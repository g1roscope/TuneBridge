# Звук — Experimental Adapter

This adapter uses the unofficial Python library **zvuk-music**.

## Rules

- The adapter is marked `is_experimental = True`.
- It can be disabled via configuration.
- TuneBridge never asks for a password.
- The user must obtain a token themselves (browser DevTools → cookie `auth` or `/api/tiny/profile`) and paste it.
- Anonymous mode is available but limited.
- If the library stops working, the application reports a clear error and falls back to JSON/CSV export.

## Installation

```bash
pip install zvuk-music
```

## Disclaimer

This is not an official integration. Use at your own risk and in accordance with Звук terms of service.
