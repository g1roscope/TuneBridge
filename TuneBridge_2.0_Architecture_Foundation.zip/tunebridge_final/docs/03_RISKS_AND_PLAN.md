# Технические риски и план разработки

## Риски

| Риск | Вероятность | Влияние | Митигация |
|------|-------------|---------|-----------|
| Поломка неофициального Звука | Высокая | Среднее | Isolated adapter + feature flag + JSON fallback |
| Квоты YouTube Data API | Высокая | Среднее | Кэширование, предупреждения, ограничение размера плейлистов |
| Получение SoundCloud ключей | Средняя | Среднее | Документировать требования, сделать опциональным |
| Apple Developer аккаунт | Высокая | Высокое | Отложить до появления аккаунта |
| OAuth redirect на Desktop | Средняя | Высокое | localhost redirect + custom URI scheme (`tunebridge://`) |
| SSRF через пользовательский URL | Средняя | Высокое | Строгий whitelist доменов |
| Хранение токенов | Высокая | Высокое | Только server-side или DPAPI/Windows Credential Manager |
| Изменения API сервисов | Средняя | Высокое | Версионирование адаптеров, мониторинг |
| Matching ложных срабатываний | Средняя | Высокое | Никогда не auto-add ambiguous, ручной выбор |

## План разработки (приоритеты)

### Этап 0 — Фундамент (текущий)
- [x] Аудит 0.1.0
- [x] Контракт адаптеров + Capabilities
- [x] Улучшенный Matching Engine
- [x] Модели данных
- [x] Архитектурное решение Desktop + API
- [ ] C# Desktop skeleton
- [ ] Единый TransferService в API

### Этап 1 — Первый реальный перенос (MVP)
1. Spotify adapter (read public + search + create + add) — полностью рабочий
2. Local JSON/CSV (уже есть)
3. Matching end-to-end
4. Минимальный WPF UI: вставка URL → preview → export
5. Self-contained publish Windows

**Критерий готовности MVP:** пользователь вставляет публичную ссылку Spotify, видит matching, экспортирует JSON/CSV. После OAuth — создаёт реальный плейлист.

### Этап 2 — OAuth + Write
- Spotify OAuth (PKCE) в Desktop
- Реальный create playlist + add tracks
- Безопасное хранение токена
- Подтверждение перед записью

### Этап 3 — Расширение адаптеров
- Deezer
- Tidal
- SoundCloud (если ключи доступны)
- Звук Experimental
- YouTube Music (ограниченный)
- Apple Music (когда появится аккаунт)

### Этап 4 — Качество
- Полные тесты (pytest + xUnit)
- Обработка ошибок и rate-limit
- История переносов (локально в Desktop)
- Проверка результата после создания

### Этап 5 — Публичный веб
- React frontend на том же API
- Guest mode в браузере
- Тот же matching и те же адаптеры

## Что уже работает в текущем фундаменте

- Модели Track / Playlist / MatchResult / TransferReport / ProviderCapabilities
- Matching с version tags и правильными порогами
- Local JSON/CSV import/export
- Контракт MusicProvider
- Каркас Spotify-адаптера
- Каркас Experimental Звук-адаптера
- Документация архитектуры и рисков

## Что пока НЕ реализовано

- Живые вызовы Spotify API (нужны client_id/secret и тесты)
- OAuth flows
- WPF интерфейс
- TransferService orchestration
- Остальные 5 адаптеров
- PostgreSQL / Redis
- Self-contained backend для offline режима
