# Аудит TuneBridge 0.1.0

Дата аудита: 2026-11-06

## Структура

```
tunebridge/
├── pyproject.toml, requirements.txt, LICENSE, README.md
├── tests/test_matcher.py          (4 теста)
└── tunebridge/
    ├── models.py                  Track, Playlist, MatchResult, TransferReport
    ├── matcher.py                 normalize + score + find_match
    ├── transfer.py                build_report + build_export_playlist
    ├── app.py                     FastAPI (analyze + export)
    ├── adapters/
    │   ├── base.py                ABC MusicProvider (5 методов)
    │   └── local.py               JSON/CSV only
    └── static/                    простой HTML/CSS/JS
```

## Что реально работает

- Импорт JSON (объект или массив треков) и CSV.
- Нормализация метаданных.
- Matching по ISRC (жёсткий), title/artist/album/duration (взвешенный score).
- Статусы: matched / ambiguous / missing.
- Экспорт результата в JSON или CSV с сохранением порядка.
- Базовые unit-тесты matcher’а.
- Простой веб-интерфейс для загрузки файла и просмотра отчёта.

## Что является заглушкой или отсутствует

- Ни одного реального музыкального сервиса.
- OAuth полностью отсутствует.
- Нет parse_playlist_url, get_capabilities, разделения public/private.
- Нет создания плейлистов в аккаунте пользователя.
- Нет поиска треков на стороне сервисов.
- Frontend — один HTML-файл, не React.
- Нет PostgreSQL, Redis, фоновых задач, истории, rate-limit.
- В README упоминаются Yandex Music и VK — они не входят в текущее ТЗ.

## Качество кода

- Чистый, читаемый Python 3.10+.
- Pydantic v2 модели корректны.
- Matcher детерминированный и тестируемый.
- Хорошая основа для ядра matching и file-transfer.
- Адаптерный контракт слишком узкий для 7 сервисов.

## Вывод

0.1.0 — рабочий **core matching + local import/export**.  
Его нужно сохранить и расширить, а не выбрасывать.  
Живых интеграций и Windows-клиента в нём нет.
