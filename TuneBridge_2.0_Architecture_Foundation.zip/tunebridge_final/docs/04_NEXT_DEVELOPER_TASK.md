# Конкретное первое задание следующему разработчику

## Цель

Сделать первый **реальный** импорт публичного плейлиста Spotify + matching + экспорт, работающий из Windows-приложения.

## Задачи (по порядку)

### 1. Довести Spotify-адаптер до рабочего состояния
Файл: `src/TuneBridge.Api/app/adapters/spotify.py`

- Реализовать получение Client Credentials token (для публичных плейлистов и поиска).
- Реализовать `get_playlist_with_token` (уже почти есть) и протестировать на реальной публичной ссылке.
- Реализовать `search_track_with_token`.
- Добавить unit-тесты с моками httpx (не живые ключи в CI).

### 2. TransferService
Создать `src/TuneBridge.Api/app/services/transfer.py`:

```python
async def import_from_url(url: str) -> Playlist
async def match_playlist(source: Playlist, destination_provider: str) -> TransferReport
async def export_report(...) -> bytes
```

Сервис должен:
- определить провайдер по URL
- вызвать адаптер
- для каждого трека вызвать search на destination
- собрать TransferReport через существующий matcher

### 3. API endpoints
- `POST /api/import`  { "url": "..." }
- `POST /api/match`   { "playlist": {...}, "destination": "spotify" }
- `POST /api/export`  (уже был в 0.1.0, перенести)

### 4. Подключить Desktop
В `MainWindow.xaml.cs`:
- вызвать `/api/import`
- показать количество треков и простую таблицу
- кнопка «Экспорт JSON»

### 5. Конфигурация
- `SPOTIFY_CLIENT_ID` / `SPOTIFY_CLIENT_SECRET` только через environment / user secrets.
- Никогда не коммитить секреты.

## Критерий приёмки

1. Пользователь вставляет публичную ссылку Spotify-плейлиста.
2. Приложение показывает список треков.
3. Пользователь выбирает destination = Spotify (или local).
4. Получает TransferReport с matched/ambiguous/missing.
5. Может скачать JSON/CSV.

OAuth и реальное создание плейлиста — **следующий** этап после этого.

## Чего делать нельзя

- Не добавлять остальные 6 адаптеров, пока Spotify не работает end-to-end.
- Не ставить «успех» без реального HTTP-ответа от Spotify.
- Не хранить client_secret в коде.
