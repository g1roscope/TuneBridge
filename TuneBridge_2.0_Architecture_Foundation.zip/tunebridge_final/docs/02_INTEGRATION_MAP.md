# Карта интеграций семи сервисов (ноябрь 2026)

Статус готовности:
- **Ready** — можно реализовывать прямо сейчас
- **Partial** — официальный API есть, но есть существенные ограничения
- **Experimental** — только неофициальный путь
- **Blocked** — требуется аккаунт разработчика / квота / дополнительная проверка

| Сервис | Способ | Публичный плейлист | Поиск | Создание плейлиста | Добавление треков | OAuth / Auth | ISRC | Статус | Реализуемо сейчас |
|--------|--------|--------------------|-------|--------------------|-------------------|--------------|------|--------|-------------------|
| **Spotify** | Official Web API | Да | Да | Да | Да | Auth Code + PKCE | Да | Ready | Да |
| **Deezer** | Official API | Да | Да | Да | Да | OAuth 2.0 | Да | Ready | Да |
| **Tidal** | Official API v2 | Да | Да | Да | Да | OAuth 2.0 + PKCE | Да | Ready | Да |
| **SoundCloud** | Official API | Да | Да | Да | Да | OAuth 2.1 + PKCE | Нет | Partial | Да (ключи часто только Artist Pro) |
| **YouTube Music** | YouTube Data API v3 | Частично (YouTube playlists) | Ограничено | Да | Да | OAuth 2.0 | Нет | Partial | Ограниченно (квота 10k units) |
| **Apple Music** | Apple Music API | Каталог — да | Да | Да | Да | Developer Token + Music User Token | Да | Blocked | Нужен Apple Developer аккаунт |
| **Звук** | Неофициальный (zvuk-music) | Да | Да | Да | Да | User token (ручной) | Нет | Experimental | Да, с пометкой Experimental |

## Детали по сервисам

### Spotify
- Самый зрелый и документированный.
- С 2025 обязателен PKCE / запрет implicit grant.
- Scopes: `playlist-read-private`, `playlist-modify-public`, `playlist-modify-private`.
- Рекомендуемый первый write-адаптер.

### Deezer
- Простой и стабильный.
- `manage_library` scope для записи.
- Хороший кандидат №2.

### Tidal
- JSON:API, современный.
- Хорошая документация на developer.tidal.com.
- Кандидат №3.

### SoundCloud
- OAuth 2.1 с 2024.
- Получение ключей в 2026 стало проще для Artist Pro, но не для всех.
- Нужна проверка актуального доступа.

### YouTube Music
- Полноценного официального YTM API нет.
- YouTube Data API позволяет работать с плейлистами, но это не полный YTM.
- Неофициальные клиенты (ytmusicapi) используют cookies — **запрещены** правилами проекта.
- Реализуем только то, что даёт Data API + честно указываем ограничения.

### Apple Music
- Требует платный Apple Developer аккаунт + JWT developer token.
- Music User Token получается через MusicKit.
- Пока ставим в очередь после появления аккаунта.

### Звук (Experimental)
- Библиотека `zvuk-music` v0.6.3 (актуальна на октябрь 2026).
- Поддерживает: anonymous token, user token, search, get playlist, create playlist, add tracks.
- Пользователь сам копирует токен из браузера.
- Адаптер изолирован, отключаемый, помечен Experimental.
- При поломке библиотеки — graceful degradation + JSON fallback.

## Правило проекта

Интеграция считается **рабочей** только после реальных тестов с живыми аккаунтами.  
Заглушки и «успешные» ответы без реальных вызовов API запрещены.
