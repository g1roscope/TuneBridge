# Окончательная архитектура TuneBridge

## Решение

Основной продукт первой версии — **Windows Desktop приложение** (C# / .NET 8, WPF).

Серверная логика и все интеграции с музыкальными сервисами живут в **Python FastAPI**.

Будущий веб-сайт (React + TypeScript + Tailwind) будет использовать тот же API.

Пользователь Windows-приложения **не устанавливает Python**.  
Приложение либо:
- работает с удалённым публичным API, либо
- запускает локальный self-contained backend (опционально, для offline/privacy режима).

## Структура репозитория

```
TuneBridge/
├── docs/                          # вся техническая документация
├── src/
│   ├── TuneBridge.Core/           # общие модели и контракты (JSON Schema + C# records)
│   ├── TuneBridge.Matching/       # чистая логика сопоставления (можно портировать)
│   ├── TuneBridge.Adapters/       # Python-адаптеры всех 7 сервисов
│   ├── TuneBridge.Api/            # FastAPI backend
│   ├── TuneBridge.Desktop/        # C# WPF приложение (.NET 8)
│   ├── TuneBridge.Web/            # будущий React frontend
│   └── TuneBridge.Tests/          # pytest + xUnit
├── scripts/
└── LICENSE (MIT)
```

### Почему такое разделение

| Компонент              | Технология     | Почему |
|------------------------|----------------|--------|
| Desktop UI             | C# + WPF       | Нативный Windows, self-contained publish, знакомый UX |
| Matching engine        | Python (и позже C#) | Уже есть рабочий код, легко тестировать |
| Adapters               | Python + HTTPX | Все музыкальные API — HTTP. Python быстрее для прототипирования и библиотек (zvuk-music) |
| API                    | FastAPI         | Единая точка для Desktop и будущего Web |
| Core models            | Shared contracts | Desktop и API говорят на одном языке (JSON) |

### Переиспользование при создании сайта

- Весь `TuneBridge.Api` + `TuneBridge.Adapters` + `TuneBridge.Matching` остаются без изменений.
- `TuneBridge.Web` просто становится ещё одним клиентом того же API.
- Модели из `TuneBridge.Core` используются и в TypeScript (через OpenAPI codegen).

## Потоки данных

### Guest mode (без авторизации)
1. Desktop → POST /api/import (URL или файл)
2. API определяет сервис → вызывает адаптер → возвращает Playlist
3. Desktop показывает треки
4. Пользователь выбирает destination
5. API делает matching (search на destination)
6. Desktop показывает отчёт (matched / ambiguous / missing)
7. Пользователь может выбрать альтернативы
8. Экспорт JSON/CSV или (после OAuth) реальный перенос

### Authenticated transfer
1. Desktop запускает OAuth flow (system browser + localhost redirect или custom URI scheme)
2. Токен хранится только на стороне API (или encrypted в local store Desktop)
3. После подтверждения API создаёт плейлист и добавляет треки
4. Возвращает реальную ссылку

## Безопасность

- Токены никогда не попадают в логи.
- SSRF-защита при разборе пользовательских URL (whitelist доменов сервисов).
- Rate limiting на API.
- Experimental-адаптеры отключаются флагом конфигурации.
- Никаких паролей и cookie-hijacking.

## Self-contained Desktop

```bash
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

Пользователь получает один .exe (или установщик).
