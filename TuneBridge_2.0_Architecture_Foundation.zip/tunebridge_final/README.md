# TuneBridge 2.0

**One library. Every music platform.**

Открытый продукт для реального переноса музыкальных плейлистов между сервисами.

## Текущий статус

**2.0.0-dev — Architectural Foundation**

- Аудит 0.1.0 выполнен
- Архитектура Desktop (C#) + API (Python) зафиксирована
- Контракт адаптеров и Matching Engine готовы
- Каркас Spotify + Experimental Звук
- Skeleton Windows-приложения (WPF)

**Ещё не работает:** живой вызов API сервисов, OAuth, полный UI, остальные адаптеры.

## Быстрый обзор структуры

```
src/
  TuneBridge.Api/          Python FastAPI + adapters + matching
  TuneBridge.Desktop/      C# WPF (.NET 8) — основной клиент
  TuneBridge.Core/         Shared contracts
  TuneBridge.Matching/     (логика сейчас внутри Api)
  TuneBridge.Adapters/     (логика сейчас внутри Api)
  TuneBridge.Web/          Будущий React
  TuneBridge.Tests/
docs/
  00_AUDIT_0.1.0.md
  01_ARCHITECTURE.md
  02_INTEGRATION_MAP.md
  03_RISKS_AND_PLAN.md
```

## Принципы

1. Настоящий перенос, а не имитация.
2. Guest First.
3. Official OAuth only (кроме явно помеченного Experimental).
4. Никаких паролей и cookie-hijacking.
5. Windows-пользователь не ставит Python.
6. Один и тот же backend для Desktop и будущего сайта.

## Лицензия

MIT
