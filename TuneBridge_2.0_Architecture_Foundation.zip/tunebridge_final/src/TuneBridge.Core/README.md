# TuneBridge.Core

Shared contracts between Desktop (C#), API (Python) and future Web (TypeScript).

Models are defined as:
- Python Pydantic models (source of truth for runtime)
- JSON Schema (this folder) for documentation and codegen
- C# records will be generated or hand-written to match exactly

Do not put business logic here. Only data shapes and enums.
