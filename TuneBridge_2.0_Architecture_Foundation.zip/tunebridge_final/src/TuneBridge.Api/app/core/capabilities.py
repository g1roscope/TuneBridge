from __future__ import annotations

from .models import ProviderCapabilities

# Predefined capability sets for documentation and tests

SPOTIFY_CAPS = ProviderCapabilities(
    can_parse_url=True,
    can_read_public=True,
    can_read_private=True,
    can_search=True,
    can_create_playlist=True,
    can_add_tracks=True,
    supports_isrc=True,
    requires_oauth=True,
    is_experimental=False,
    notes="Official Spotify Web API. Requires Authorization Code + PKCE.",
)

DEEZER_CAPS = ProviderCapabilities(
    can_parse_url=True,
    can_read_public=True,
    can_read_private=True,
    can_search=True,
    can_create_playlist=True,
    can_add_tracks=True,
    supports_isrc=True,
    requires_oauth=True,
    is_experimental=False,
    notes="Official Deezer API. manage_library scope required for writes.",
)

TIDAL_CAPS = ProviderCapabilities(
    can_parse_url=True,
    can_read_public=True,
    can_read_private=True,
    can_search=True,
    can_create_playlist=True,
    can_add_tracks=True,
    supports_isrc=True,
    requires_oauth=True,
    is_experimental=False,
    notes="Official TIDAL API v2 (JSON:API). PKCE supported.",
)

SOUNDCLOUD_CAPS = ProviderCapabilities(
    can_parse_url=True,
    can_read_public=True,
    can_read_private=True,
    can_search=True,
    can_create_playlist=True,
    can_add_tracks=True,
    supports_isrc=False,
    requires_oauth=True,
    is_experimental=False,
    notes="Official SoundCloud API. OAuth 2.1 + PKCE. Keys often limited to Artist Pro.",
)

YOUTUBE_MUSIC_CAPS = ProviderCapabilities(
    can_parse_url=True,
    can_read_public=True,
    can_read_private=False,  # limited via Data API
    can_search=True,
    can_create_playlist=True,
    can_add_tracks=True,
    supports_isrc=False,
    requires_oauth=True,
    is_experimental=False,
    notes="YouTube Data API v3. Quota limited. Full YTM features require unofficial clients (not used).",
)

APPLE_MUSIC_CAPS = ProviderCapabilities(
    can_parse_url=True,
    can_read_public=True,
    can_read_private=True,
    can_search=True,
    can_create_playlist=True,
    can_add_tracks=True,
    supports_isrc=True,
    requires_oauth=True,
    is_experimental=False,
    notes="Apple Music API. Requires Apple Developer account + Music User Token.",
)

ZVUK_CAPS = ProviderCapabilities(
    can_parse_url=True,
    can_read_public=True,
    can_read_private=True,
    can_search=True,
    can_create_playlist=True,
    can_add_tracks=True,
    supports_isrc=False,
    requires_oauth=False,  # uses user-provided token
    is_experimental=True,
    notes="EXPERIMENTAL. Uses unofficial zvuk-music library. User must supply own token. No password collection.",
)

LOCAL_CAPS = ProviderCapabilities(
    can_parse_url=False,
    can_read_public=False,
    can_read_private=False,
    can_search=False,
    can_create_playlist=False,
    can_add_tracks=False,
    supports_isrc=False,
    requires_oauth=False,
    is_experimental=False,
    notes="File-based import/export only (JSON/CSV).",
)
