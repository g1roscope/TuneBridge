from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher

from .models import MatchCandidate, MatchResult, MatchStatus, Track


# Common version markers we care about
VERSION_PATTERNS = [
    (r"\blive\b", "live"),
    (r"\bremix\b", "remix"),
    (r"\bremaster(?:ed)?\b", "remastered"),
    (r"\bacoustic\b", "acoustic"),
    (r"\binstrumental\b", "instrumental"),
    (r"\bradio\s*edit\b", "radio_edit"),
    (r"\bexplicit\b", "explicit"),
    (r"\bclean\b", "clean"),
    (r"\bdeluxe\b", "deluxe"),
    (r"\bextended\b", "extended"),
    (r"\bbonus\b", "bonus"),
]


def normalize(value: str | None) -> str:
    value = unicodedata.normalize("NFKD", value or "")
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = value.casefold()
    # Remove common noise in parentheses/brackets
    value = re.sub(
        r"\([^)]*(official|lyrics?|audio|video|visualizer|hd|4k|music\s*video)[^)]*\)",
        " ",
        value,
    )
    value = re.sub(
        r"\[[^\]]*(official|lyrics?|audio|video|visualizer|hd|4k|music\s*video)[^\]]*\]",
        " ",
        value,
    )
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return " ".join(value.split())


def extract_version_tags(title: str, album: str = "") -> list[str]:
    text = f"{title} {album}".casefold()
    tags: list[str] = []
    for pattern, tag in VERSION_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            tags.append(tag)
    return tags


def similarity(a: str, b: str) -> float:
    na, nb = normalize(a), normalize(b)
    if not na or not nb:
        return 0.0
    return SequenceMatcher(None, na, nb).ratio()


def score_track(source: Track, candidate: Track) -> tuple[float, list[str]]:
    """
    Returns (score 0.0-1.0, list of human-readable reasons).
    """
    # 1. Exact ISRC is decisive
    if source.isrc and candidate.isrc and source.isrc.upper() == candidate.isrc.upper():
        return 1.0, ["Exact ISRC match"]

    title_score = similarity(source.title, candidate.title)
    artist_score = similarity(source.artist, candidate.artist)
    album_score = (
        similarity(source.album, candidate.album)
        if source.album and candidate.album
        else 0.5
    )

    duration_score = 0.5
    if source.duration_ms and candidate.duration_ms:
        delta = abs(source.duration_ms - candidate.duration_ms)
        # Tolerate up to ~12 seconds difference
        duration_score = max(0.0, 1.0 - delta / 12000.0)

    # Version penalty / bonus
    src_tags = set(source.version_tags or extract_version_tags(source.title, source.album))
    cand_tags = set(candidate.version_tags or extract_version_tags(candidate.title, candidate.album))
    version_penalty = 0.0
    if src_tags or cand_tags:
        if src_tags == cand_tags:
            version_penalty = 0.0  # perfect match
        elif src_tags & cand_tags:
            version_penalty = -0.05  # partial overlap
        else:
            version_penalty = -0.15  # different version (live vs studio etc.)

    score = (
        title_score * 0.50
        + artist_score * 0.32
        + album_score * 0.08
        + duration_score * 0.10
        + version_penalty
    )
    score = max(0.0, min(1.0, score))

    reasons = [
        f"title {title_score:.0%}",
        f"artist {artist_score:.0%}",
    ]
    if source.duration_ms and candidate.duration_ms:
        delta_s = abs(source.duration_ms - candidate.duration_ms) / 1000
        reasons.append(f"duration Δ {delta_s:.1f}s")
    if src_tags or cand_tags:
        reasons.append(f"versions src={sorted(src_tags)} cand={sorted(cand_tags)}")

    return score, reasons


def find_match(
    source: Track,
    candidates: list[Track],
    *,
    matched_threshold: float = 0.82,
    ambiguous_threshold: float = 0.55,
    max_candidates: int = 5,
) -> MatchResult:
    """
    Rank candidates and decide status.
    Never auto-select a low-confidence match.
    """
    if not candidates:
        return MatchResult(
            source=source,
            status=MatchStatus.MISSING,
            reasons=["No candidates returned"],
        )

    ranked: list[tuple[float, list[str], Track]] = []
    for item in candidates:
        sc, reasons = score_track(source, item)
        ranked.append((sc, reasons, item))

    ranked.sort(key=lambda x: x[0], reverse=True)

    best_score, best_reasons, best_track = ranked[0]
    top_candidates = [
        MatchCandidate(track=t, score=s, reasons=r)
        for s, r, t in ranked[:max_candidates]
    ]

    # Decide status
    if best_score >= matched_threshold:
        # Check if second place is dangerously close → ambiguous
        if len(ranked) > 1 and (best_score - ranked[1][0]) < 0.08:
            status = MatchStatus.AMBIGUOUS
        else:
            status = MatchStatus.MATCHED
    elif best_score >= ambiguous_threshold:
        status = MatchStatus.AMBIGUOUS
    else:
        status = MatchStatus.MISSING

    return MatchResult(
        source=source,
        candidate=best_track if status != MatchStatus.MISSING else None,
        candidates=top_candidates,
        score=best_score,
        status=status,
        reasons=best_reasons,
    )
