"""
TuneBridge 2.0 — FastAPI entry point.

Guest-first playlist transfer between music platforms.
"""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path

app = FastAPI(
    title="TuneBridge",
    description="One library. Every music platform.",
    version="2.0.0-dev",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static frontend (will be replaced by React build later)
static_dir = Path(__file__).parent.parent / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "2.0.0-dev"}


@app.get("/api/providers")
async def list_providers_endpoint():
    from app.adapters.registry import list_providers
    result = []
    for p in list_providers():
        caps = p.get_capabilities()
        result.append({
            "id": p.provider_id,
            "name": p.display_name,
            "experimental": p.is_experimental,
            "capabilities": caps.model_dump(),
        })
    return result


# TODO: /api/parse-url, /api/import, /api/match, /api/transfer, /api/export
# These will be added in the next iteration once Spotify + matching are solid.
