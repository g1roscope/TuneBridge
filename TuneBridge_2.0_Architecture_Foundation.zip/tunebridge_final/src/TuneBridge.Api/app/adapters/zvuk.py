"""
Звук (formerly СберЗвук) — EXPERIMENTAL adapter.

Uses the unofficial library `zvuk-music` (https://github.com/trudenboy/zvuk-music).

Rules enforced by TuneBridge:
- Never collect passwords.
- Never automatically intercept cookies.
- User must supply their own token (or use anonymous limited mode).
- This adapter is clearly marked Experimental and can be disabled.
- If the library breaks, the application must degrade gracefully.
"""
from __future__ import annotations

import re
from typing import Sequence

from app.adapters.base import MusicProvider
from app.core.capabilities import ZVUK_CAPS
from app.core.models import (
    AuthToken,
    ParsedPlaylistRef,
    Playlist,
    ProviderCapabilities,
    Track,
)

# Optional dependency
try:
    from zvuk_music import Client as ZvukClient
    ZVUK_AVAILABLE = True
except ImportError:
    ZvukClient = None  # type: ignore
    ZVUK_AVAILABLE = False


class ZvukProvider(MusicProvider):
    provider_id = "zvuk"
    display_name = "Звук (Experimental)"
    is_experimental = True

    _url_patterns = [
        r"zvuk\.com/playlist/",
        r"sber-zvuk\.com/playlist/",
    ]

    def __init__(self, token: str | None = None):
        self._token = token
        self._client: ZvukClient | None = None

    def get_capabilities(self) -> ProviderCapabilities:
        caps = ZVUK_CAPS.model_copy()
        if not ZVUK_AVAILABLE:
            caps.notes += " | Library zvuk-music is not installed — adapter disabled."
            caps.can_read_public = False
            caps.can_search = False
            caps.can_create_playlist = False
            caps.can_add_tracks = False
        return caps

    def _ensure_client(self, token: AuthToken | None = None) -> "ZvukClient":
        if not ZVUK_AVAILABLE:
            raise RuntimeError(
                "zvuk-music library is not installed. "
                "Install with: pip install zvuk-music"
            )
        tok = (token.access_token if token else None) or self._token
        if not tok:
            # Fall back to anonymous (limited)
            tok = ZvukClient.get_anonymous_token()
        if self._client is None or True:  # always recreate for safety
            self._client = ZvukClient(token=tok)
        return self._client

    async def parse_playlist_url(self, url: str) -> ParsedPlaylistRef | None:
        m = re.search(r"(?:zvuk\.com|sber-zvuk\.com)/playlist/(\d+)", url)
        if not m:
            return None
        return ParsedPlaylistRef(
            provider_id=self.provider_id,
            playlist_id=m.group(1),
            url=url,
            is_public=True,
        )

    def _track_from_zvuk(self, item, position: int = 0) -> Track:
        # zvuk-music models vary slightly between versions; be defensive
        title = getattr(item, "title", None) or getattr(item, "name", "") or ""
        artists = ""
        if hasattr(item, "get_artists_str"):
            artists = item.get_artists_str()
        elif hasattr(item, "artists"):
            arts = item.artists or []
            artists = ", ".join(getattr(a, "title", str(a)) for a in arts)
        album = ""
        if hasattr(item, "release") and item.release:
            album = getattr(item.release, "title", "") or ""
        duration_ms = None
        if hasattr(item, "duration"):
            # may be seconds
            d = item.duration
            duration_ms = int(d * 1000) if d and d < 10000 else int(d) if d else None
        track_id = str(getattr(item, "id", "") or "")
        return Track(
            title=title,
            artist=artists,
            album=album,
            duration_ms=duration_ms,
            provider_ids={"zvuk": track_id},
            position=position,
        )

    async def get_public_playlist(self, ref: ParsedPlaylistRef) -> Playlist:
        client = self._ensure_client()
        # Library is synchronous; wrap if needed
        pl = client.get_playlist(int(ref.playlist_id))
        tracks_data = client.get_playlist_tracks(int(ref.playlist_id))
        tracks = [self._track_from_zvuk(t, i) for i, t in enumerate(tracks_data or [])]
        name = getattr(pl, "title", None) or getattr(pl, "name", "Zvuk playlist")
        return Playlist(
            name=name,
            description=getattr(pl, "description", "") or "",
            tracks=tracks,
            source_service=self.provider_id,
            source_url=ref.url,
            external_id=ref.playlist_id,
        )

    async def get_private_playlist(self, playlist_id: str, token: AuthToken) -> Playlist:
        client = self._ensure_client(token)
        pl = client.get_playlist(int(playlist_id))
        tracks_data = client.get_playlist_tracks(int(playlist_id))
        tracks = [self._track_from_zvuk(t, i) for i, t in enumerate(tracks_data or [])]
        name = getattr(pl, "title", None) or getattr(pl, "name", "Zvuk playlist")
        return Playlist(
            name=name,
            description=getattr(pl, "description", "") or "",
            tracks=tracks,
            source_service=self.provider_id,
            external_id=playlist_id,
        )

    async def search_track(self, track: Track, limit: int = 10) -> list[Track]:
        client = self._ensure_client()
        query = f"{track.artist} {track.title}".strip()
        results = client.quick_search(query)
        items = getattr(results, "tracks", None) or []
        return [self._track_from_zvuk(t, i) for i, t in enumerate(items[:limit])]

    async def create_playlist(
        self,
        name: str,
        description: str = "",
        token: AuthToken | None = None,
        public: bool = False,
    ) -> str:
        client = self._ensure_client(token)
        # zvuk-music create_playlist(name, track_ids=...)
        playlist_id = client.create_playlist(name)
        return str(playlist_id)

    async def add_tracks(
        self,
        playlist_id: str,
        tracks: Sequence[Track],
        token: AuthToken | None = None,
    ) -> None:
        client = self._ensure_client(token)
        ids = [t.provider_ids["zvuk"] for t in tracks if "zvuk" in t.provider_ids]
        if ids:
            client.add_tracks_to_playlist(int(playlist_id), ids)

    async def get_playlist_url(self, playlist_id: str) -> str:
        return f"https://zvuk.com/playlist/{playlist_id}"
