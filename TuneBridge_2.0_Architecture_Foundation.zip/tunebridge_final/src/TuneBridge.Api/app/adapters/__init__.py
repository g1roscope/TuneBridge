from app.adapters.base import MusicProvider
from app.adapters.local import LocalProvider
from app.adapters.registry import get_provider, list_providers, register

# Import concrete providers so they can register themselves if needed
try:
    from app.adapters.spotify import SpotifyProvider
except ImportError:
    pass

try:
    from app.adapters.zvuk import ZvukProvider
except ImportError:
    pass

__all__ = [
    "MusicProvider",
    "LocalProvider",
    "get_provider",
    "list_providers",
    "register",
]
