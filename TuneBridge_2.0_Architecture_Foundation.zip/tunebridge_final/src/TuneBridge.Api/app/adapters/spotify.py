"""
Spotify adapter — official Web API.

Requires:
  SPOTIFY_CLIENT_ID
  SPOTIFY_CLIENT_SECRET
  SPOTIFY_REDIRECT_URI

OAuth: Authorization Code + PKCE (recommended) or Authorization Code.
Never store client secret in frontend.
"""
from __future__ import annotations

import re
from typing import Sequence
from urllib.parse import urlencode

import httpx

from app.adapters.base import MusicProvider
from app.core.capabilities import SPOTIFY_CAPS
from app.core.models import (
    AuthToken,
    ParsedPlaylistRef,
    Playlist,
    ProviderCapabilities,
    Track,
)

SPOTIFY_API = "https://api.spotify.com/v1"
SPOTIFY_ACCOUNTS = "https://accounts.spotify.com"


class SpotifyProvider(MusicProvider):
    provider_id = "spotify"
    display_name = "Spotify"
    is_experimental = False

    # Used by registry for quick URL detection
    _url_patterns = [
        r"open\.spotify\.com/playlist/",
        r"spotify:playlist:",
    ]

    def __init__(self, client_id: str | None = None, client_secret: str | None = None):
        self.client_id = client_id
        self.client_secret = client_secret

    def get_capabilities(self) -> ProviderCapabilities:
        return SPOTIFY_CAPS

    # ------------------------------------------------------------------
    # URL parsing
    # ------------------------------------------------------------------

    async def parse_playlist_url(self, url: str) -> ParsedPlaylistRef | None:
        # https://open.spotify.com/playlist/37i9dQZF1DXcBWIGoYBM5M
        # spotify:playlist:37i9dQZF1DXcBWIGoYBM5M
        m = re.search(
            r"(?:open\.spotify\.com/playlist/|spotify:playlist:)([a-zA-Z0-9]+)",
            url,
        )
        if not m:
            return None
        playlist_id = m.group(1)
        return ParsedPlaylistRef(
            provider_id=self.provider_id,
            playlist_id=playlist_id,
            url=url,
            is_public=True,  # will be verified later
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _headers(self, token: AuthToken | None = None) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if token:
            headers["Authorization"] = f"{token.token_type} {token.access_token}"
        return headers

    async def _get(self, path: str, token: AuthToken, params: dict | None = None) -> dict:
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.get(
                f"{SPOTIFY_API}{path}",
                headers=self._headers(token),
                params=params,
            )
            r.raise_for_status()
            return r.json()

    async def _post(self, path: str, token: AuthToken, json_body: dict) -> dict:
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(
                f"{SPOTIFY_API}{path}",
                headers=self._headers(token),
                json=json_body,
            )
            r.raise_for_status()
            return r.json()

    def _track_from_spotify(self, item: dict, position: int = 0) -> Track:
        track = item.get("track") or item
        artists = ", ".join(a["name"] for a in track.get("artists", []))
        album = (track.get("album") or {}).get("name", "")
        isrc = None
        external = track.get("external_ids") or {}
        if "isrc" in external:
            isrc = external["isrc"]
        return Track(
            title=track.get("name", ""),
            artist=artists,
            album=album,
            duration_ms=track.get("duration_ms"),
            isrc=isrc,
            source_url=(track.get("external_urls") or {}).get("spotify"),
            provider_ids={"spotify": track.get("id", "")},
            position=position,
            metadata={
                "explicit": track.get("explicit"),
                "popularity": track.get("popularity"),
            },
        )

    # ------------------------------------------------------------------
    # Public / private playlist
    # ------------------------------------------------------------------

    async def get_public_playlist(self, ref: ParsedPlaylistRef) -> Playlist:
        """
        Public playlists can be fetched with a client-credentials token
        or any user token. For simplicity we require a token here;
        the application layer should obtain a suitable one.
        """
        # Placeholder: real implementation needs a token.
        # In production the transfer service supplies a client-credentials
        # or user token.
        raise NotImplementedError(
            "get_public_playlist requires a valid Spotify token. "
            "Use get_playlist_with_token in the service layer."
        )

    async def get_playlist_with_token(
        self, playlist_id: str, token: AuthToken
    ) -> Playlist:
        data = await self._get(f"/playlists/{playlist_id}", token, params={"market": "from_token"})
        tracks: list[Track] = []
        items = data.get("tracks", {}).get("items", [])
        next_url = data.get("tracks", {}).get("next")

        pos = 0
        for item in items:
            if item.get("track"):
                tracks.append(self._track_from_spotify(item, pos))
                pos += 1

        # Pagination
        async with httpx.AsyncClient(timeout=30.0) as client:
            while next_url:
                r = await client.get(next_url, headers=self._headers(token))
                r.raise_for_status()
                page = r.json()
                for item in page.get("items", []):
                    if item.get("track"):
                        tracks.append(self._track_from_spotify(item, pos))
                        pos += 1
                next_url = page.get("next")

        return Playlist(
            name=data.get("name", "Spotify playlist"),
            description=data.get("description") or "",
            tracks=tracks,
            source_service=self.provider_id,
            source_url=data.get("external_urls", {}).get("spotify"),
            external_id=playlist_id,
        )

    async def get_private_playlist(self, playlist_id: str, token: AuthToken) -> Playlist:
        return await self.get_playlist_with_token(playlist_id, token)

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    async def search_track(self, track: Track, limit: int = 10) -> list[Track]:
        """
        Search requires a user or client-credentials token.
        Prefer ISRC when available.
        """
        raise NotImplementedError(
            "search_track requires a token. Call search_track_with_token from the service layer."
        )

    async def search_track_with_token(
        self, track: Track, token: AuthToken, limit: int = 10
    ) -> list[Track]:
        if track.isrc:
            q = f"isrc:{track.isrc}"
        else:
            parts = []
            if track.title:
                parts.append(f'track:"{track.title}"')
            if track.artist:
                parts.append(f'artist:"{track.artist}"')
            q = " ".join(parts) or track.title

        data = await self._get(
            "/search",
            token,
            params={"q": q, "type": "track", "limit": limit},
        )
        items = data.get("tracks", {}).get("items", [])
        return [self._track_from_spotify(item, i) for i, item in enumerate(items)]

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    async def create_playlist(
        self,
        name: str,
        description: str = "",
        token: AuthToken | None = None,
        public: bool = False,
    ) -> str:
        if token is None:
            raise ValueError("Spotify create_playlist requires an AuthToken")
        # Need current user id
        me = await self._get("/me", token)
        user_id = me["id"]
        body = {
            "name": name,
            "description": description,
            "public": public,
        }
        data = await self._post(f"/users/{user_id}/playlists", token, body)
        return data["id"]

    async def add_tracks(
        self,
        playlist_id: str,
        tracks: Sequence[Track],
        token: AuthToken | None = None,
    ) -> None:
        if token is None:
            raise ValueError("Spotify add_tracks requires an AuthToken")
        uris = []
        for t in tracks:
            sid = t.provider_ids.get("spotify")
            if sid:
                uris.append(f"spotify:track:{sid}")
        # Spotify allows max 100 items per request
        async with httpx.AsyncClient(timeout=30.0) as client:
            for i in range(0, len(uris), 100):
                chunk = uris[i : i + 100]
                r = await client.post(
                    f"{SPOTIFY_API}/playlists/{playlist_id}/items",
                    headers=self._headers(token),
                    json={"uris": chunk},
                )
                r.raise_for_status()

    async def get_playlist_url(self, playlist_id: str) -> str:
        return f"https://open.spotify.com/playlist/{playlist_id}"

    # ------------------------------------------------------------------
    # OAuth helpers (used by auth module)
    # ------------------------------------------------------------------

    def build_authorize_url(
        self,
        redirect_uri: str,
        state: str,
        scopes: list[str] | None = None,
        code_challenge: str | None = None,
    ) -> str:
        scopes = scopes or [
            "playlist-read-private",
            "playlist-read-collaborative",
            "playlist-modify-public",
            "playlist-modify-private",
        ]
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "scope": " ".join(scopes),
            "state": state,
        }
        if code_challenge:
            params["code_challenge_method"] = "S256"
            params["code_challenge"] = code_challenge
        return f"{SPOTIFY_ACCOUNTS}/authorize?{urlencode(params)}"
