from __future__ import annotations

from typing import Type

from app.adapters.base import MusicProvider
from app.adapters.local import LocalProvider

# Lazy imports to avoid hard dependencies when optional providers are missing
_REGISTRY: dict[str, Type[MusicProvider]] = {
    "local": LocalProvider,
}


def register(provider_cls: Type[MusicProvider]) -> Type[MusicProvider]:
    """Decorator / helper to register a provider class."""
    instance = provider_cls()  # type: ignore[call-arg]
    _REGISTRY[instance.provider_id] = provider_cls
    return provider_cls


def get_provider(provider_id: str) -> MusicProvider:
    cls = _REGISTRY.get(provider_id)
    if cls is None:
        raise KeyError(f"Unknown provider: {provider_id}")
    return cls()


def list_providers() -> list[MusicProvider]:
    return [cls() for cls in _REGISTRY.values()]


def get_provider_for_url(url: str) -> MusicProvider | None:
    """Try each registered provider's parse_playlist_url until one succeeds."""
    for provider in list_providers():
        # parse is async, but we only need a quick synchronous check of patterns
        # Real resolution happens later in the request handler.
        if hasattr(provider, "_url_patterns"):
            import re
            for pattern in getattr(provider, "_url_patterns", []):
                if re.search(pattern, url, re.IGNORECASE):
                    return provider
    return None
