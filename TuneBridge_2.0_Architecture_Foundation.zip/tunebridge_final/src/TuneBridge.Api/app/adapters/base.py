from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Sequence

from app.core.models import (
    AuthToken,
    ParsedPlaylistRef,
    Playlist,
    ProviderCapabilities,
    Track,
)


class MusicProvider(ABC):
    """
    Common contract for all music service adapters.

    Not every method must be implemented by every provider.
    Check get_capabilities() before calling write / private methods.
    """

    provider_id: str
    display_name: str
    is_experimental: bool = False

    @abstractmethod
    def get_capabilities(self) -> ProviderCapabilities:
        """Return what this provider currently supports."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # URL parsing
    # ------------------------------------------------------------------

    async def parse_playlist_url(self, url: str) -> ParsedPlaylistRef | None:
        """
        Try to extract a playlist reference from a URL.
        Return None if the URL does not belong to this provider.
        """
        return None

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    async def get_public_playlist(self, ref: ParsedPlaylistRef) -> Playlist:
        """Fetch a publicly accessible playlist."""
        raise NotImplementedError(f"{self.provider_id} does not support public playlist read")

    async def get_private_playlist(self, playlist_id: str, token: AuthToken) -> Playlist:
        """Fetch a private / user-owned playlist. Requires valid token."""
        raise NotImplementedError(f"{self.provider_id} does not support private playlist read")

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    async def search_track(self, track: Track, limit: int = 10) -> list[Track]:
        """
        Search for candidates that could match the given track.
        Should prefer ISRC when available.
        """
        raise NotImplementedError(f"{self.provider_id} does not support search")

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    async def create_playlist(
        self,
        name: str,
        description: str = "",
        token: AuthToken | None = None,
        public: bool = False,
    ) -> str:
        """
        Create a new playlist in the user's account.
        Returns the new playlist_id.
        """
        raise NotImplementedError(f"{self.provider_id} does not support playlist creation")

    async def add_tracks(
        self,
        playlist_id: str,
        tracks: Sequence[Track],
        token: AuthToken | None = None,
    ) -> None:
        """
        Append tracks to an existing playlist.
        Tracks must already contain the provider-specific ID
        in track.provider_ids[self.provider_id].
        """
        raise NotImplementedError(f"{self.provider_id} does not support adding tracks")

    async def get_playlist_url(self, playlist_id: str) -> str:
        """Return a shareable URL for the given playlist."""
        raise NotImplementedError(f"{self.provider_id} does not support playlist URL generation")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        exp = " [EXPERIMENTAL]" if self.is_experimental else ""
        return f"<{self.__class__.__name__} {self.provider_id}{exp}>"
