"""File-based adapter used for JSON/CSV import & export (Guest mode)."""
from __future__ import annotations

import csv
import io
import json
import re
from typing import Any

from app.adapters.base import MusicProvider
from app.core.capabilities import LOCAL_CAPS
from app.core.models import Playlist, ProviderCapabilities, Track


def _parse_duration(value: Any) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        # assume milliseconds if large, else seconds
        v = int(value)
        return v if v > 10000 else v * 1000
    s = str(value).strip()
    if re.fullmatch(r"\d+", s):
        v = int(s)
        return v if v > 10000 else v * 1000
    # mm:ss or h:mm:ss
    parts = s.split(":")
    try:
        parts = [int(p) for p in parts]
        if len(parts) == 2:
            return (parts[0] * 60 + parts[1]) * 1000
        if len(parts) == 3:
            return (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000
    except ValueError:
        pass
    return None


def parse_playlist_json(raw: str) -> Playlist:
    data = json.loads(raw)
    if isinstance(data, list):
        data = {"tracks": data}
    if not isinstance(data, dict) or not isinstance(data.get("tracks", []), list):
        raise ValueError("JSON must be a playlist object or an array of tracks")

    tracks: list[Track] = []
    for i, item in enumerate(data.get("tracks", [])):
        item = dict(item)
        title = str(item.get("title") or item.get("name") or "").strip()
        if not title:
            continue
        artist = str(item.get("artist") or item.get("artists") or "").strip()
        if isinstance(item.get("artists"), list):
            artist = ", ".join(str(a) for a in item["artists"])
        duration_ms = item.get("duration_ms")
        if duration_ms is None:
            duration_ms = _parse_duration(item.get("duration"))
        tracks.append(
            Track(
                title=title,
                artist=artist,
                album=str(item.get("album") or "").strip(),
                duration_ms=duration_ms,
                isrc=str(item["isrc"]).strip().upper() if item.get("isrc") else None,
                source_url=item.get("url") or item.get("source_url"),
                provider_ids=item.get("provider_ids") or {},
                position=i,
                metadata={k: v for k, v in item.items() if k not in {
                    "title", "name", "artist", "artists", "album",
                    "duration_ms", "duration", "isrc", "url", "source_url", "provider_ids"
                }},
            )
        )

    return Playlist(
        name=str(data.get("name") or "Imported playlist"),
        description=str(data.get("description") or ""),
        tracks=tracks,
        source_service="file",
    )


def parse_playlist_csv(raw: str) -> Playlist:
    reader = csv.DictReader(io.StringIO(raw))
    if not reader.fieldnames:
        raise ValueError("CSV has no headers")

    # normalize headers
    field_map = {h.lower().strip(): h for h in reader.fieldnames}
    tracks: list[Track] = []
    for i, row in enumerate(reader):
        title = (row.get(field_map.get("title", "")) or row.get(field_map.get("name", "")) or "").strip()
        if not title:
            continue
        artist = (row.get(field_map.get("artist", "")) or "").strip()
        album = (row.get(field_map.get("album", "")) or "").strip()
        duration_ms = _parse_duration(
            row.get(field_map.get("duration_ms", "")) or row.get(field_map.get("duration", ""))
        )
        isrc = (row.get(field_map.get("isrc", "")) or "").strip().upper() or None
        url = (row.get(field_map.get("url", "")) or row.get(field_map.get("source_url", "")) or None)
        tracks.append(
            Track(
                title=title,
                artist=artist,
                album=album,
                duration_ms=duration_ms,
                isrc=isrc,
                source_url=url,
                position=i,
            )
        )

    return Playlist(name="Imported playlist", tracks=tracks, source_service="file")


class LocalProvider(MusicProvider):
    provider_id = "local"
    display_name = "Local file (JSON / CSV)"
    is_experimental = False

    def get_capabilities(self) -> ProviderCapabilities:
        return LOCAL_CAPS
