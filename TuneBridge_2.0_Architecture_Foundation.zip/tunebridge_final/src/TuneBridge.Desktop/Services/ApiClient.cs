using System.Net.Http;
using System.Net.Http.Json;

namespace TuneBridge.Desktop.Services;

/// <summary>
/// Thin HTTP client that talks to TuneBridge.Api.
/// All music-service logic lives on the server.
/// </summary>
public sealed class ApiClient
{
    private readonly HttpClient _http;

    public ApiClient(HttpClient http)
    {
        _http = http;
    }

    public async Task<string> HealthAsync(CancellationToken ct = default)
    {
        var response = await _http.GetAsync("/api/health", ct);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadAsStringAsync(ct);
    }

    // Future methods:
    // ImportPlaylistAsync(url)
    // MatchAsync(playlist, destination)
    // TransferAsync(...)
}
