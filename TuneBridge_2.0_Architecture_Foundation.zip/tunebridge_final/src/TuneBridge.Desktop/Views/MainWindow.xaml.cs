using System.Windows;

namespace TuneBridge.Desktop.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void OnImportClick(object sender, RoutedEventArgs e)
    {
        var url = UrlBox.Text?.Trim();
        if (string.IsNullOrWhiteSpace(url))
        {
            StatusText.Text = "Вставьте ссылку на плейлист.";
            return;
        }

        // TODO: call TuneBridge.Api
        StatusText.Text = $"Получена ссылка:\n{url}\n\nСледующий шаг — подключение к API и реальному адаптеру.";
    }
}
