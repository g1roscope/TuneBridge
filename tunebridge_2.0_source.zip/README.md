# TuneBridge 2.0 (Desktop Edition)

TuneBridge 2.0 is a native Windows WPF application built with .NET 8 for seamless playlist transfer across music streaming platforms.

## Supported Platforms (MVP & Architecture)
1. Spotify
2. YouTube Music
3. Apple Music
4. Deezer
5. Tidal
6. SoundCloud
7. Звук (Experimental)

## Building the EXE
To build a standalone executable (`TuneBridge.exe`) for Windows 10/11 x64 without requiring the .NET Runtime on the target machine:

```bash
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
```

The resulting standalone executable will be located in:
`bin/Release/net8.0-windows/win-x64/publish/TuneBridge.exe`
