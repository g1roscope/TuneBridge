using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using TuneBridge.Desktop.Core.Adapters;
using TuneBridge.Desktop.Core.Matcher;
using TuneBridge.Desktop.Core.Models;

namespace TuneBridge.Desktop.UI
{
    public partial class MainWindow : Window
    {
        private List<MatchResult> _results = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void BtnImport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BtnImport.IsEnabled = false;
                TxtStatus.Text = "Fetching playlist from source...";

                IBaseAdapter adapter = new SpotifyAdapter();
                var playlist = await adapter.GetPublicPlaylistAsync(TxtUrl.Text);

                TxtStatus.Text = "Matching tracks...";
                _results.Clear();

                foreach (var track in playlist.Tracks)
                {
                    var candidates = await adapter.SearchTrackAsync(track);
                    var match = MatchEngine.FindMatch(track, candidates);
                    _results.Add(match);
                }

                DgTracks.ItemsSource = null;
                DgTracks.ItemsSource = _results;
                TxtStatus.Text = $"Successfully processed {_results.Count} tracks.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during import: {ex.Message}", "TuneBridge Error", MessageBoxButton.OK, MessageBoxImage.Error);
                TxtStatus.Text = "Error occurred.";
            }
            finally
            {
                BtnImport.IsEnabled = true;
            }
        }

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            if (_results.Count == 0)
            {
                MessageBox.Show("No data to export.", "TuneBridge", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                FileName = "tunebridge-export",
                DefaultExt = ".json",
                Filter = "JSON files (.json)|*.json|CSV files (.csv)|*.csv"
            };

            if (dialog.ShowDialog() == true)
            {
                var json = System.Text.Json.JsonSerializer.Serialize(_results, new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(dialog.FileName, json);
                TxtStatus.Text = $"Exported successfully to {Path.GetFileName(dialog.FileName)}";
            }
        }
    }
}
