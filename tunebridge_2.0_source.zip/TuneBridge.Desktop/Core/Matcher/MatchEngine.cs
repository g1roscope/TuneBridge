using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using TuneBridge.Desktop.Core.Models;

namespace TuneBridge.Desktop.Core.Matcher
{
    public static class MatchEngine
    {
        public static string Normalize(string? value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            value = value.Normalize(System.Text.NormalizationForm.FormKD);
            value = new string(value.Where(ch => System.Globalization.CharUnicodeInfo.GetUnicodeCategory(ch) != System.Globalization.UnicodeCategory.NonSpacingMark).ToArray());
            value = value.ToLowerInvariant();
            value = Regex.Replace(value, @"\([^)]*(official|lyrics?|audio|video|remaster|version)[^)]*\)", " ");
            value = Regex.Replace(value, @"\[[^\]]*(official|lyrics?|audio|video|remaster|version)[^\]*\]", " ");
            value = Regex.Replace(value, @"[^a-z0-9]+", " ");
            return string.Join(" ", value.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
        }

        public static double Similarity(string a, string b)
        {
            var na = Normalize(a);
            var nb = Normalize(b);
            if (string.IsNullOrEmpty(na) || string.IsNullOrEmpty(nb)) return 0.0;
            
            // Levenshtein / Sequence similarity approximation
            int distance = ComputeLevenshteinDistance(na, nb);
            int maxLength = Math.Max(na.Length, nb.Length);
            if (maxLength == 0) return 1.0;
            return 1.0 - (double)distance / maxLength;
        }

        private static int ComputeLevenshteinDistance(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            var d = new int[n + 1, m + 1];

            if (n == 0) return m;
            if (m == 0) return n;

            for (int i = 0; i <= n; d[i, 0] = i++) ;
            for (int j = 0; j <= m; d[0, j] = j++) ;

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            return d[n, m];
        }

        public static (double score, List<string> reasons) ScoreTrack(Track source, Track candidate)
        {
            if (!string.IsNullOrEmpty(source.Isrc) && !string.IsNullOrEmpty(candidate.Isrc) &&
                string.Equals(source.Isrc, candidate.Isrc, StringComparison.OrdinalIgnoreCase))
            {
                return (1.0, new List<string> { "Exact ISRC match" });
            }

            double titleScore = Similarity(source.Title, candidate.Title);
            double artistScore = Similarity(source.Artist, candidate.Artist);
            double albumScore = (!string.IsNullOrEmpty(source.Album) && !string.IsNullOrEmpty(candidate.Album)) 
                ? Similarity(source.Album, candidate.Album) 
                : 0.5;

            double durationScore = 0.5;
            if (source.DurationMs.HasValue && candidate.DurationMs.HasValue)
            {
                int delta = Math.Abs(source.DurationMs.Value - candidate.DurationMs.Value);
                durationScore = Math.Max(0.0, 1.0 - delta / 12000.0);
            }

            double score = titleScore * 0.52 + artistScore * 0.34 + albumScore * 0.06 + durationScore * 0.08;
            var reasons = new List<string>
            {
                $"title {titleScore:P0}",
                $"artist {artistScore:P0}"
            };

            if (source.DurationMs.HasValue && candidate.DurationMs.HasValue)
            {
                double diffSec = Math.Abs(source.DurationMs.Value - candidate.DurationMs.Value) / 1000.0;
                reasons.Add($"duration difference {diffSec:F1}s");
            }

            return (score, reasons);
        }

        public static MatchResult FindMatch(Track source, List<Track> candidates)
        {
            if (candidates == null || candidates.Count == 0)
            {
                return new MatchResult { Source = source, Status = "missing", Reasons = new List<string> { "No candidates returned" } };
            }

            var ranked = candidates
                .Select(c => {
                    var (score, reasons) = ScoreTrack(source, c);
                    return new { Candidate = c, Score = score, Reasons = reasons };
                })
                .OrderByDescending(x => x.Score)
                .ToList();

            var best = ranked[0];
            double secondScore = ranked.Count > 1 ? ranked[1].Score : 0.0;

            string status;
            if (best.Score >= 0.88 && (best.Score - secondScore) >= 0.035)
            {
                status = "matched";
            }
            else if (best.Score >= 0.68)
            {
                status = "ambiguous";
            }
            else
            {
                status = "missing";
            }

            var reasons = new List<string>(best.Reasons);
            if (status == "missing")
            {
                return new MatchResult { Source = source, Candidate = null, Score = best.Score, Status = "missing", Reasons = reasons };
            }
            if (status == "ambiguous")
            {
                reasons.Add("Review required: similar or uncertain result");
            }

            return new MatchResult { Source = source, Candidate = best.Candidate, Score = best.Score, Status = status, Reasons = reasons };
        }
    }
}
