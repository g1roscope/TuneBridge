using System.Collections.Generic;
using System.Threading.Tasks;
using TuneBridge.Desktop.Core.Models;

namespace TuneBridge.Desktop.Core.Adapters
{
    public interface IBaseAdapter
    {
        string ProviderId { get; }
        string DisplayName { get; }
        bool IsExperimental { get; }
        
        Task<Playlist> GetPublicPlaylistAsync(string url);
        Task<List<Track>> SearchTrackAsync(Track track);
        Task<string> CreatePlaylistAsync(string name, string description = "");
        Task AddTracksAsync(string playlistId, List<Track> tracks);
    }
}
