using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TuneBridge.Desktop.Core.Models;

namespace TuneBridge.Desktop.Core.Adapters
{
    public class ZvukAdapter : IBaseAdapter
    {
        public string ProviderId => "zvuk";
        public string DisplayName => "Звук [Experimental]";
        public bool IsExperimental => true;

        public async Task<Playlist> GetPublicPlaylistAsync(string url)
        {
            await Task.Delay(500);
            return new Playlist
            {
                Name = "Sample Zvuk Playlist",
                Description = "Imported via Zvuk Experimental Adapter",
                SourceService = ProviderId,
                Tracks = new List<Track>
                {
                    new Track { Title = "Кукла колдуна", Artist = "Король и Шут", Album = "Акустический альбом", DurationMs = 202000 }
                }
            };
        }

        public async Task<List<Track>> SearchTrackAsync(Track track)
        {
            await Task.Delay(200);
            return new List<Track>
            {
                new Track { Title = track.Title, Artist = track.Artist, Album = track.Album, DurationMs = track.DurationMs }
            };
        }

        public async Task<string> CreatePlaylistAsync(string name, string description = "")
        {
            await Task.Delay(500);
            return "zvuk_playlist_id_999";
        }

        public async Task AddTracksAsync(string playlistId, List<Track> tracks)
        {
            await Task.Delay(300);
        }
    }
}
