using System.Collections.Generic;

namespace TuneBridge.Desktop.Core.Models
{
    public class MatchResult
    {
        public Track Source { get; set; } = null!;
        public Track? Candidate { get; set; }
        public double Score { get; set; }
        public string Status { get; set; } = "missing"; // matched, ambiguous, missing
        public List<string> Reasons { get; set; } = new();
    }
}
