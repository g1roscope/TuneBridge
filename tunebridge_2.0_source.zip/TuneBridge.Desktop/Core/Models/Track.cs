using System.Collections.Generic;

namespace TuneBridge.Desktop.Core.Models
{
    public class Track
    {
        public string Title { get; set; } = string.Empty;
        public string Artist { get; set; } = string.Empty;
        public string Album { get; set; } = string.Empty;
        public int? DurationMs { get; set; }
        public string? Isrc { get; set; }
        public string? SourceUrl { get; set; }
        public Dictionary<string, string> ProviderIds { get; set; } = new();
        public int Position { get; set; }
        public Dictionary<string, object> Metadata { get; set; } = new();
    }
}
