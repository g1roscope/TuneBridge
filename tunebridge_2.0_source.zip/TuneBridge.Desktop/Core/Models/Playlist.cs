using System.Collections.Generic;

namespace TuneBridge.Desktop.Core.Models
{
    public class Playlist
    {
        public string Name { get; set; } = "Imported playlist";
        public string Description { get; set; } = string.Empty;
        public List<Track> Tracks { get; set; } = new();
        public string SourceService { get; set; } = "file";
    }
}
